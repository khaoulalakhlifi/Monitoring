# app/routes.py

from flask import render_template, request, jsonify
from app import app, db
from app.models import Client

@app.route('/')
def index():
    clients = Client.query.all()
    return render_template('index.html', clients=clients)

@app.route('/clients', methods=['GET'])
def get_clients():
    clients = Client.query.all()
    clients_list = [{'id': client.id, 'name': client.name, 'ip_address': client.ip_address,
                     'mac_address': client.mac_address, 'longitude': client.longitude,
                     'latitude': client.latitude, 'created_at': client.created_at} for client in clients]
    return jsonify({'clients': clients_list})

@app.route('/clients/<int:client_id>', methods=['GET'])
def get_client(client_id):
    client = Client.query.get_or_404(client_id)
    client_info = {'id': client.id, 'name': client.name, 'ip_address': client.ip_address,
                   'mac_address': client.mac_address, 'longitude': client.longitude,
                   'latitude': client.latitude, 'created_at': client.created_at}
    return jsonify({'client': client_info})

@app.route('/clients', methods=['POST'])
def add_client():
    data = request.get_json()

    new_client = Client(name=data['name'],
                        ip_address=data['ip_address'],
                        mac_address=data['mac_address'],
                        longitude=data['longitude'],
                        latitude=data['latitude'])

    db.session.add(new_client)
    db.session.commit()

    return jsonify({'message': 'Client added successfully!'}), 201

@app.route('/clients/<int:client_id>', methods=['PUT'])
def update_client(client_id):
    client = Client.query.get_or_404(client_id)
    data = request.get_json()

    client.name = data['name']
    client.ip_address = data['ip_address']
    client.mac_address = data['mac_address']
    client.longitude = data['longitude']
    client.latitude = data['latitude']

    db.session.commit()

    return jsonify({'message': 'Client updated successfully!'})

@app.route('/clients/<int:client_id>', methods=['DELETE'])
def delete_client(client_id):
    client = Client.query.get_or_404(client_id)
    db.session.delete(client)
    db.session.commit()

    return jsonify({'message': 'Client deleted successfully!'})
